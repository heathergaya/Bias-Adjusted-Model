
list.of.packages <- c('rjags', 'runjags', 'mixAK', 'miscF', 'Rdistance', "lme4", "Rcpp")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
lapply(list.of.packages,function(x){library(x,character.only=TRUE)})

js <- "
$(document).ready(function() {
$('#runmodel').on('click', function(){
var date = new Date().toLocaleString();
$('#busy').html('Model started: ' + date);
});
$('#model.ran').on('shiny:value', function(event) {
$('#busy').html('');
});
});
$(document).ready(function() {
$('#extendmodel').on('click', function(){
var date = new Date().toLocaleString();
$('#busy2').html('Model started: ' + date);
});
$('#model.extended').on('shiny:value', function(event) {
$('#busy2').html('');
});
});
"


library(shiny)

# Define server logic ----
server <- function(input, output) {
  output$min_max <- renderText({ 
    paste("You have chosen a range that goes from",
          input$slider[1], "to", input$slider[2])
  })
  output$slidermax <- renderText({ 
    paste("The model will run for a maximum of",
          input$timeslider, "hours")
  })
  output$file <- renderTable({
    head.Burrows()
  })

    
  output$file2 <- renderTable({
    head.Trans()
  })
  
  
  
  observeEvent(input$prepmodel, {
    inFile <- isolate({input$file })
    Burrows <<- read.csv(inFile$datapath)
    inFile2 <- isolate({input$file2 })
    Trans <<- read.csv(inFile2$datapath)
    p.min <<- input$slider[1]
    p.max <<- input$slider[2]
    maxusrtime <<- paste(input$timeslider, "h")
    source('RJMCMC.R')
    source('Bias_Adjusted_Model.R')
    output$model.prepped <- renderText({
      paste("The model is loaded!")
    })
  })
  
  observeEvent(input$runmodel, {
    Run.me(Burrows)
  })
  
  observeEvent(input$runmodel, {
    output$model.ran <- renderTable({
      summary(Foo)[,c(1:5,11)]
    })})
  
  observeEvent(input$extendmodel, {
    Extend.me(Burrows)
    output$model.extended <- renderTable({
      summary(Foo)[,c(1:5,11)]
    })})
  
  observeEvent(input$plotmodel, {
      Plot.me.shiny(Burrows)
      output$model.plotted <- renderPlot({
        plot(xs, Kall*Occ, type = "l", main = "Estimated Size Curve for Population",
             col = "black", lwd =2,  cex.lab = 1.5, cex.axis = 1.5, cex.main = 1.5, xlab = "Burrow Width in cm",
             ylab = "", yaxt = "n", ylim = c(-.0002, max(Kall*Occ)+.0005))
        percents <- Covmod[c("juvi1", "juvi2", "juvi3"), 4]
        legend("topright", c(paste(round(percents[1],2)*100, "%", "  ", "< 13 cm"), 
                             paste(round(percents[2],2)*100, "%", "  ", "13-22 cm"), 
                             paste(100- round(percents[3],2)*100, "%", "  ", "> 22 cm")), 
               text.col = c("darkgreen", "purple", "blue"), cex = 1.35)
        arrows(4, -.0002, 12.9, -.0002, length = 0.075, col = "darkgreen", code = 3, angle = 30, lwd = 2)
        arrows(13, -.0002, 21.9, -.0002, length = 0.075, col = "purple", code = 3, angle = 30, lwd = 2)
        arrows(22, -.0002, 65, -.0002, length = 0.075, col = "blue", code = 3, angle = 30, lwd = 2)
    })
    })
  
  head.Burrows <- reactive({
    infile <- input$file
    if (is.null(infile)) {
      # User has not uploaded a file yet
      return(NULL)
    }
    head(read.csv(infile$datapath, header = T), n =2)
    
  })
  
  head.Trans <- reactive({
    infile2 <- input$file2
    if (is.null(infile2)) {
      # User has not uploaded a file yet
      return(NULL)
    }
    head(read.csv(infile2$datapath, header = T), n= 2)
  })
  
}



# Define UI ----
ui <- fluidPage(
  tags$head(
    tags$script(HTML(js))
  ),
  titlePanel("Bayesian LTDS"),
  
  fluidRow(
    
    column(3,
           fileInput("file", h3("Burrow Data (.csv)"), 
                     accept=c('text/csv', 'text/comma-separated-values,text/plain'))),
    column(5, tableOutput("file"))),
  
  
  fluidRow(
    column(3,
           fileInput("file2", h3("Transect Data (.csv)"),
                     accept=c('text/csv', 'text/comma-separated-values,text/plain'))),
    
    column(5, tableOutput("file2"))
  ),
  
  fluidRow(
    
    column(3, 
           sliderInput("slider", label = "Estimated Detection on the Line for 5 cm Burrows",
                       min = 0, max = 1, value = c(.4, .6))
    ),  
    textOutput("min_max")),
  fluidRow(
    
    column(3, 
           sliderInput("timeslider", label = "Maximum Time for Model Run",
                       min = 0, max = 10, value = 4, step = .25)
    ),  
    textOutput("slidermax")),
  
  fluidRow(
           
    column(5, offset = 2,
           actionButton("prepmodel", "Load the Model")), 
    textOutput("model.prepped")
  ),
  
  fluidRow(
      column(5, offset =2,
           actionButton("runmodel", "Run the Model")),
      tags$p(id = "busy")
  ),
  
  fluidRow(
    column(5, offset =2,
           actionButton("extendmodel", "Extend the Model")),
    tags$p(id = "busy2")),
  
  
  fluidRow(
    column(5, offset =2,
           actionButton("plotmodel", "Plot the Size Curve")),
    column(5, plotOutput("model.plotted")
    )),
  
  fluidRow(
    column(5, align = "center", tableOutput("model.ran"))),
  
  fluidRow(
    column(5, align = "center", tableOutput("model.extended")))
  
)


# Run the app ----
shinyApp(ui = ui, server = server)

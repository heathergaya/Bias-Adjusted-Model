
setwd("C:/Users/heg08492.MYID/Desktop/Thesis_Things/Learning_Bayes/Bayes_LTDS")

Burrows <- read.csv("Example_Burrow_Data.csv", header = TRUE)

Trans <- read.csv("Example_Transect_Data.csv", header = TRUE)

p.min <- .6
p.max <- .8

source('Bias_Adjusted_Model.R')
Run.me(Burrows)

Extend.me(Burrows)
Plot.me(Burrows)


